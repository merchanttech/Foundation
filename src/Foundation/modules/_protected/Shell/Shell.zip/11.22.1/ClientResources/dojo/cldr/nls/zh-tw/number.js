//>>built
define("dojo/cldr/nls/zh-tw/number",{"currencyFormat":"¤#,##0.00","decimalFormat-short":"000T","nan":"非數值"});