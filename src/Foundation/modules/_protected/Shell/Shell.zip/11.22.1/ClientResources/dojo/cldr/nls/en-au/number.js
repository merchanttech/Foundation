//>>built
define("dojo/cldr/nls/en-au/number",{"currencyFormat":"¤#,##0.00"});